pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
    }
    plugins {
        id("org.jetbrains.compose") version "1.7.0"
        id("org.jetbrains.kotlin.jvm") version "2.0.0"
    }
}
rootProject.name = "planner-desktop-mvp"
